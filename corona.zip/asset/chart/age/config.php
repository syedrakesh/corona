<?php
	$db_name = "syedrake_covid19";
	$host_name = "localhost";
	$user_name = "syedrake_covid19";
	$password = "syedrake_covid19";
?>