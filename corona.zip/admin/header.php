		<div class="row">
			<div class="col-6">
			    <div class="d-flex justify-content-start">
			        <div class="mt-3">
						<a href="home.php">
							<button class="btn btn-success">
							    <i class="fa fa-home" aria-hidden="true">
							        Home
							    </i>
							</button>
						</a>
					</div>
			    </div>
			</div>
			<div class="col-6">
				<div class="d-flex d-flex justify-content-end">
					<div class="mt-3">
						<a href="logout.php">
							<button class="btn btn-danger">
							    <i class="fa fa-sign-out" aria-hidden="true">
							        Logout
							    </i>
							</button>
						</a>
					</div>
				</div>
			</div>
		</div>
		<br/>